<?php
interface ItemInterface {
	public function __construct($itemID, \Database $Database);
}
?>