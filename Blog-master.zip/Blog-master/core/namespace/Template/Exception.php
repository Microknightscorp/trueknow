<?php
namespace Template;

class Exception extends \Exception {}
?>