<?php
namespace Page;

class Exception extends \Exception {}
?>