<?php
namespace Page;

class Factory extends \ItemFactory {}
?>