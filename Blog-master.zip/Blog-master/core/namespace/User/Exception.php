<?php
namespace User;

class Exception extends \Exception {}
?>