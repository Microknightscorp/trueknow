<?php
namespace Post;

class Exception extends \Exception {}
?>