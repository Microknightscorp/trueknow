<?php
namespace Post;

class Factory extends \ItemFactory {}
?>