<?php
interface FactoryInterface {
	public static function build($identifier);
}
?>