<h1><i class="fa fa-pencil-square-o"></i><?=$Language->text('update_user')?></h1>
<p><?=$Language->text('update_user_desc')?></p>

<?=$HTML?>