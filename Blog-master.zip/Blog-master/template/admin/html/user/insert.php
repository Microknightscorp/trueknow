<h1><i class="fa fa-pencil-square-o"></i><?=$Language->text('insert_user')?></h1>
<p><?=$Language->text('insert_user_desc')?></p>

<?=$HTML?>