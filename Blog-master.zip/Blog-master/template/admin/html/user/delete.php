<h1><i class="fa fa-trash-o"></i><?=$Language->text('delete_user')?></h1>
<p><?=$Language->text('delete_user_desc')?></p>

<p class="red"><?=$Language->text('delete_user_warning')?></p>

<?=$HTML?>