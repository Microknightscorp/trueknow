<h1><i class="fa fa-trash-o"></i><?=$Language->text('delete_page')?></h1>
<p><?=$Language->text('delete_page_desc')?></p>

<?=$HTML?>