<h1><i class="fa fa-pencil-square-o"></i><?=$Language->text('insert_page')?></h1>
<p><?=$Language->text('insert_page_desc')?></p>

<?=$HTML?>