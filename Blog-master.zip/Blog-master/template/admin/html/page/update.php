<h1><i class="fa fa-pencil-square-o"></i><?=$Language->text('update_page')?></h1>
<p><?=$Language->text('update_page_desc')?></p>

<?=$HTML?>