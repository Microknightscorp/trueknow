<h1><i class="fa fa-pencil-square-o"></i><?=$Language->text('insert_post')?></h1>
<p><?=$Language->text('insert_post_desc')?></p>

<?=$HTML?>