<h1><i class="fa fa-trash-o"></i><?=$Language->text('delete_post')?></h1>
<p><?=$Language->text('delete_post_desc')?></p>

<?=$HTML?>